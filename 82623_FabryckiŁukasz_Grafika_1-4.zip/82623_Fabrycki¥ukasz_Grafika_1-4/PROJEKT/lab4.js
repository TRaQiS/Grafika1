$.fn.shuffleChildren = function() {
    $.each(this.get(), function(index, el) {
        var $el = $(el);
        var $find = $el.children();

        $find.sort(function() {
            return 0.5 - Math.random();
        });

        $el.empty();
        $find.appendTo($el);
    });
};

    

const tasowanie = window.addEventListener('load', () => {
    $(".cards").shuffleChildren();
})



function sprawdz_end() {
    var win = 1
    var cards_in_game = [...document.querySelectorAll('.flip-card-inner')]
    cards_in_game.forEach((e) => {
        // console.log(e.style.transform)
        if(e.style.transform != 'rotateY(180deg)') {
            win = 0
        }
    })

    if(win != 0){
        setTimeout(()=> {
            document.querySelector('#win-ruchy').innerText = ruchy
            document.querySelector('.win').style.display = 'flex'
            document.querySelector('.gra').style.filter = 'blur(10px)'
        }, gamevars.timeout)
    }
    // $(".cards").shuffleChildren();
}

var gamevars = {
    'timeout': 800,
    'kontrolka': false,
    'klikniecia': 0
}

var old_card = 0
var card = 0
var old_card_name
var card_name
var target_old
var ruchy = 0

document.querySelector('#gra-ruchy').innerText = ruchy

const game = document.querySelector('.cards').addEventListener('click', (e) => {
    if(gamevars.kontrolka == false){
        game_click(e)
    }
})

function game_click(e) {
    if(e.target.getAttribute('alt') == 'card') {
        gamevars.kontrolka = true
        if(card == e.target.getAttribute('data-id')) return
        if(gamevars.klikniecia < 2) gamevars.klikniecia++
        if(gamevars.klikniecia == 2) {
            old_card = card
            old_card_name = card_name
            card_name = e.target.getAttribute('data-name')
            card = e.target.getAttribute('data-id')
            e.target.parentElement.parentElement.style.transform = 'rotateY(180deg)'
            if(old_card_name != card_name) {
                setTimeout(() => {
                    target_old.style.transform = 'rotateY(0deg)'
                    e.target.parentElement.parentElement.style.transform = 'rotateY(0deg)'
                }, gamevars.timeout)
            }
            old_card_name = ''
            card_name = ''
            old_card = 0
            card = 0
            gamevars.klikniecia = 0
            sprawdz_end()
        } else if(gamevars.klikniecia == 1) {
            card_name = e.target.getAttribute('data-name')
            card = e.target.getAttribute('data-id')
            target_old = e.target.parentElement.parentElement
            e.target.parentElement.parentElement.style.transform = 'rotateY(180deg)'
        }
        ruchy++
        document.querySelector('#gra-ruchy').innerText = ruchy
    }
    setTimeout(() => {
        gamevars.kontrolka = false
    }, gamevars.timeout)
}