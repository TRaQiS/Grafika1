const load = window.addEventListener('load', () => {
    const canvas = document.getElementById('canvas');
    canvas.width = 800;
    canvas.height = 600;
    const ctx = canvas.getContext('2d');
    
    var tab_a
    var tab_b

    tab_a = [118, 118, 134, 122]
    tab_b = [68, 53, 200, 191]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [122, 110, 55, 55]
    tab_b = [182, 182, 224, 239]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [55, 55, 66, 55]
    tab_b = [239, 254, 299, 310]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [55, 44, 125, 125]
    tab_b = [310, 321, 255, 240]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [125, 125, 141, 126]
    tab_b = [240, 225, 381, 381]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [126, 111, 324, 322]
    tab_b = [381, 381, 372, 387]
    rysujkrzywa(ctx, tab_a, tab_b)


    tab_a = [322, 320, 343, 328]
    tab_b = [387, 402, 341, 341]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [328, 313, 185, 184]
    tab_b = [341, 341, 323, 338]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [184, 183, 187, 176]
    tab_b = [338, 353, 222, 232]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [176, 165, 249, 243]
    tab_b = [232, 242, 161, 175]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [243, 237, 238, 226]
    tab_b = [175, 189, 143, 133]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [226, 214, 177, 177]
    tab_b = [133, 123, 189, 174]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [177, 177, 192, 177]
    tab_b = [174, 159, 63, 60]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [177, 162, 141, 126]
    tab_b = [60, 57, 72, 69]
    rysujkrzywa(ctx, tab_a, tab_b)


    //F
    tab_a = [396, 396, 407, 392]
    tab_b = [122, 107, 415, 415]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [392, 377, 439, 439]
    tab_b = [415, 415, 401, 416]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [439, 439, 456, 441]
    tab_b = [416, 431, 235, 234]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [441, 426, 504, 504]
    tab_b = [234, 233, 222, 237]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [504, 504, 518, 503]
    tab_b = [237, 252, 202, 202]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [503, 488, 451, 450]
    tab_b = [202, 202, 187, 202]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [450, 449, 460, 445]
    tab_b = [202, 217, 150, 150]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [445, 430, 554, 553]
    tab_b = [150, 150, 136, 151]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [553, 552, 565, 550]
    tab_b = [151, 166, 113, 113]
    rysujkrzywa(ctx, tab_a, tab_b)

    tab_a = [550, 535, 414, 399]
    tab_b = [113, 113, 116, 116]
    rysujkrzywa(ctx, tab_a, tab_b)
})


function rysujkrzywa(ctx, tab_a, tab_b) {

    var start = { x: tab_a[0],    y: tab_b[0] }
    var pkt1 =   { x: tab_a[1],   y: tab_b[1]  }
    var pkt2 =   { x: tab_a[2],   y: tab_b[2]  }
    var end =   { x: tab_a[3],   y: tab_b[3] }

    // Krzywa
    ctx.beginPath()
    ctx.moveTo(start.x, start.y)
    ctx.bezierCurveTo(pkt1.x, pkt1.y, pkt2.x, pkt2.y, end.x, end.y)
    ctx.stroke()

    // Punkty od do
    ctx.fillStyle = 'rgba(0,0,255,0.6)'
    ctx.beginPath();
    ctx.arc(start.x, start.y, 5, 0, 2 * Math.PI)  // Start point
    ctx.arc(end.x, end.y, 5, 0, 2 * Math.PI)      // End point
    ctx.fill();

    // Punkty kontrolne
    ctx.fillStyle = 'rgba(255,0,0,0.2)'
    ctx.beginPath()
    ctx.arc(pkt1.x, pkt1.y, 5, 0, 2 * Math.PI)  // Control point one
    ctx.arc(pkt2.x, pkt2.y, 5, 0, 2 * Math.PI)  // Control point two
    ctx.fill()
}



// function bezzie(ctx, tab_a, tab_b) {
//     ctx.beginPath();
//     ctx.moveTo(tab_a[0], tab_b[0]);
//     for (var t = 0; t < 1; t += 0.00005) {
//         var xt = Math.pow(1 - t, 3) * tab_a[0] + 3 * t * Math.pow(1 - t, 2) * tab_a[1] + 3 * Math.pow(t, 2) * (1 - t) * tab_a[2] + Math.pow(t, 3) * tab_a[3];
//         var yt = Math.pow(1 - t, 3) * tab_b[0] + 3 * t * Math.pow(1 - t, 2) * tab_b[1] + 3 * Math.pow(t, 2) * (1 - t) * tab_b[2] + Math.pow(t, 3) * tab_b[3];
//         // g.draw(new Line2D.Double(xt, yt, xt, yt));
//         // console.log(xt + ' ' + yt)
        
//         ctx.lineTo(xt, yt);
//         ctx.stroke();
//     }
// }

