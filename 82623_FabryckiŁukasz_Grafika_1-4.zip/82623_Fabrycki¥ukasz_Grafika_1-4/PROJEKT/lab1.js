const load = window.addEventListener('load', () => {
    const canvas = document.querySelector('#canvas')
    const ctx = canvas.getContext('2d')

    var p = new Path2D("M10 10 h 80 v 80 h -80 Z");
    
    //Domek    
    ctx.beginPath();
    ctx.fillStyle = 'rgb(54, 56, 59)';
    ctx.fillRect(80, 80, 120, 120);

    //Komin
    ctx.beginPath();
    ctx.moveTo(190,80);
    ctx.lineTo(190,50)
    ctx.lineTo(170,50);
    ctx.lineTo(170,80)
    ctx.fillStyle = 'pink'
    ctx.fill();

    //Dach
    ctx.beginPath();
    ctx.moveTo(80,80);
    ctx.lineTo(160,60)
    ctx.lineTo(200,80)
    ctx.fillStyle = 'rgb(82, 21, 17)'
    ctx.fill();

    //Okno
    ctx.beginPath();
    ctx.moveTo(100,100)
    ctx.lineTo(100,120)
    ctx.lineTo(120,120)
    ctx.lineTo(120,100)
    ctx.fillStyle = 'rgb(10, 40, 60)'
    ctx.fill()

    //Okno 2
    ctx.beginPath();
    ctx.moveTo(180,100)
    ctx.lineTo(180,120)
    ctx.lineTo(195,120)
    ctx.lineTo(195,100)
    ctx.fillStyle = 'rgb(10, 40, 60)'
    ctx.fill()


    ctx.beginPath();
    ctx.moveTo(150,150)
    ctx.lineTo(150,120)
    ctx.lineTo(170,120)
    ctx.lineTo(170,150)
    ctx.fillStyle = 'rgba(92, 62, 51)'
    ctx.fill()

})