const canvas = document.querySelector('canvas')
const c = canvas.getContext('2d')

canvas.width = 800
canvas.height = 800
canvas.style.backgroundColor = 'green'


class Player {
    constructor() {
        this.position = {
            x: 100,
            y: 700
        }
        this.velocity = {
            x: 0,
            y: 0
        }
        this.width = 50
        this.height = 50
    }

    draw() {
        c.fillStyle = 'red'
        c.fillRect(this.position.x, this.position.y, this.width, this.height)
    }

    update() {
        this.draw()
        this.position.y += this.velocity.y
        this.position.x += this.velocity.x
    }
}
const gravity = .05
class Ball {
    constructor({x,y}) {
        this.position = {
            x: x,
            y: y
        }

        this.velocity = {
            x: 0,
            y: 0
        }
        this.range = 10
    }

    draw() {
        c.beginPath();
        c.fillStyle = 'white'
        c.arc(this.position.x, this.position.y, this.range, 0, Math.PI*2)
        c.fill()
    }

    update() {
        this.draw()
        this.position.y += this.velocity.y
        this.position.x += this.velocity.x

        if(this.position.y + this.range + this.velocity.y <= canvas.height)
            this.velocity.y += gravity
        else
            this.velocity.y = 0
    }
}

class Wall {
    constructor({x, y}) {
        this.position = {
            x: x,
            y: y
        }

        this.width = 10
        this.height = 10
    }

    draw() {
        c.fillStyle = 'black'
        c.fillRect(this.position.x, this.position.y, this.width, this.height)
    }
}

const player = new Player()
const walls = [new Wall({ x: 200, y: 790}), new Wall({ x: 600, y: 790})]
const ball = new Ball({x: 400, y: 100})

const keys = {
    right: {
        pressed: false
    },
    left: {
        pressed: false
    },
    up: {
        pressed: false
    },
    down: {
        pressed: false
    }
}

let scrollOffset = 0

function animate() {
    requestAnimationFrame(animate)
    c.clearRect(0, 0, canvas.width, canvas.height)
    walls.forEach(wall => {
        wall.draw()

        if(player.position.y + player.velocity.y <= wall.position.y + wall.height && player.position.x + player.width + player.velocity.x >= wall.position.x && player.position.y + player.height + player.velocity.y >= wall.position.y && player.position.x + player.velocity.x <= wall.position.x + wall.width) {
            player.velocity.x = 0
            player.velocity.y = 0
        }
    })
    player.update()
    ball.update()

    
    walls.forEach(wall => {
        if(keys.right.pressed && player.position.x + player.width <= canvas.width) {
            player.velocity.x = 3
        } else if(keys.left.pressed && player.position.x >= 0){
            player.velocity.x = -3
        } else {
            player.velocity.x = 0
        }

        if (keys.up.pressed && player.position.y >= 0){
            player.velocity.y = -3
        } else if(keys.down.pressed && player.position.y + player.height <= canvas.height) {
            player.velocity.y = 3
        } else {
            player.velocity.y = 0
        }
    })
}

animate()

window.addEventListener('keydown', ({ keyCode }) => {
    switch(keyCode) {
        case 37:
            keys.left.pressed = true
            break
        case 39:
            keys.right.pressed = true
            break
        case 40:
            keys.down.pressed = true
            break
        case 38:
            keys.up.pressed = true
            break
    }
})

window.addEventListener('keyup', ({ keyCode }) => {
    switch(keyCode) {
        case 37:
            keys.left.pressed = false
            break
        case 39:
            keys.right.pressed = false
            break
        case 40:
            keys.down.pressed = false
            break
        case 38:
            keys.up.pressed = false
            break
    }
})